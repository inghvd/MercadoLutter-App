MercadoLutter - Starter

Instrucciones rápidas:
1. Copiar .env.example a .env y editar (PORT=3033, MONGO_URI, SESSION_SECRET).
2. npm install
3. node create-admin.js (crea admin@mercadolutter.com / Admin123)
4. npm run dev
5. Abrir: http://localhost:3033

Recuerda cambiar la contraseña del admin y SESSION_SECRET antes de producción.
